from tkinter import Tk
from page_one import PageOne
from page_two import PageTwo
from page_three import PageThree
from page_four import PageFour
from page_five import PageFive

global page_one, page_two, page_three, page_four, page_five

def show_page_one():
    global page_one, page_two, page_three, page_four, page_five
    page_two.pack_forget()
    page_three.pack_forget()
    page_four.pack_forget()
    page_five.pack_forget()
    page_one.pack(fill='both', expand=True)

def show_page_two():
    global page_one, page_two, page_three, page_four, page_five
    page_one.pack_forget()
    page_three.pack_forget()
    page_four.pack_forget()
    page_five.pack_forget()
    page_two.pack(fill='both', expand=True)

def show_page_three():
    global page_one, page_two, page_three, page_four, page_five
    page_one.pack_forget()
    page_two.pack_forget()
    page_four.pack_forget()
    page_five.pack_forget()
    page_three.pack(fill='both', expand=True)

def show_page_four():
    global page_one, page_two, page_three, page_four, page_five
    page_one.pack_forget()
    page_two.pack_forget()
    page_three.pack_forget()
    page_five.pack_forget()
    page_four.pack(fill='both', expand=True)

def show_page_five():
    global page_one, page_two, page_three, page_four, page_five
    page_one.pack_forget()
    page_two.pack_forget()
    page_three.pack_forget()
    page_four.pack_forget()
    page_five.pack(fill='both', expand=True)

root = Tk()
root.geometry("720x480")
root.configure(bg="#FFFFFF")


page_one = PageOne(root, show_page_two, show_page_three, show_page_four, show_page_five)
page_two = PageTwo(root, show_page_one)
page_three = PageThree(root, show_page_one)
page_four = PageFour(root, show_page_one)
page_five = PageFive(root, show_page_one)


show_page_one()

root.resizable(False, False)
root.mainloop()