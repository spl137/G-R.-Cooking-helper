from tkinter import Frame, Canvas, Button, PhotoImage, Entry
from pathlib import Path

def relative_to_assets(path: str) -> Path:
    return Path(r"C:\!Учеба 2.24\Практика Самоделкин П.А\build\assets\frame5") / Path(path)

class PageOne(Frame):
    def __init__(self, master, show_page_two, show_page_three, show_page_four, show_page_five):
        super().__init__(master)
        self.show_page_two = show_page_two
        self.show_page_three = show_page_three
        self.show_page_four = show_page_four
        self.show_page_five = show_page_five
        self.create_widgets()


    def create_widgets(self):
        canvas = Canvas(
            self,
            bg="#FFFFFF",
            height=480,
            width=720,
            bd=0,
            highlightthickness=0,
            relief="ridge"
        )
        canvas.place(x=0, y=0)
        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = canvas.create_image(
            360.0,
            240.0,
            image=image_image_1
        )
        image_image_1.image = image_image_1
        image_image_2 = PhotoImage(
            file=relative_to_assets("image_2.png"))
        image_2 = canvas.create_image(
            364.0,
            139.0,
            image=image_image_2
        )
        image_image_2.image = image_image_2
        image_image_3 = PhotoImage(
            file=relative_to_assets("image_3.png"))
        image_3 = canvas.create_image(
            315.0,
            95.0,
            image=image_image_3
        )
        image_image_3.image = image_image_3
        button_image_1 = PhotoImage(
            file=relative_to_assets("button_1.png"))
        button_1 = Button(
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=self.show_page_three,
            relief="flat"
        )
        button_1.place(
            x=18.0,
            y=264.0,
            width=156.0,
            height=204.0
        )
        button_1.image = button_image_1

        button_image_2 = PhotoImage(
            file=relative_to_assets("button_2.png"))
        button_2 = Button(
            image=button_image_2,
            borderwidth=0,
            highlightthickness=0,
            command=self.show_page_four,
            relief="flat"
        )
        button_2.place(
            x=193.0,
            y=264.0,
            width=157.0,
            height=204.0
        )
        button_2.image = button_image_2

        button_image_3 = PhotoImage(
            file=relative_to_assets("button_3.png"))
        button_3 = Button(
            canvas,
            image=button_image_3,
            borderwidth=0,
            highlightthickness=0,
            command=self.show_page_five,
            relief="flat"
        )
        button_3.place(
            x=365.0,
            y=264.0,
            width=159.0,
            height=204.0
        )
        button_3.image = button_image_3

        button_image_4 = PhotoImage(
            file=relative_to_assets("button_4.png"))
        button_4 = Button(
            canvas,
            image=button_image_4,
            borderwidth=0,
            highlightthickness=0,
            command=self.show_page_two,
            relief="flat"
        )
        button_4.place(
            x=538.0,
            y=264.0,
            width=159.0,
            height=204.0
        )
        button_4.image = button_image_4

        image_image_4 = PhotoImage(
            file=relative_to_assets("image_4.png"))
        image_4 = canvas.create_image(
            356.0,
            70.0,
            image=image_image_4
        )
        image_image_4.image = image_image_4
        image_image_5 = PhotoImage(
            file=relative_to_assets("image_5.png"))
        image_5 = canvas.create_image(
            360.0,
            158.0,
            image=image_image_5
        )
        image_image_5.image = image_image_5
        entry_image_1 = PhotoImage(
            file=relative_to_assets("entry_1.png"))
        entry_bg_1 = canvas.create_image(
            341.5,
            215.5,
            image=entry_image_1
        )
        entry_1 = Entry(
            bd=0,
            bg="#472D0E",
            fg="#000716",
            highlightthickness=0
        )
        entry_1.place(
            x=204.0,
            y=200.0,
            width=275.0,
            height=29.0
        )
        entry_image_1.image = entry_image_1
        button_image_5 = PhotoImage(
            file=relative_to_assets("button_5.png"))
        button_5 = Button(
            image=button_image_5,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: print("button_5 clicked"),
            relief="flat"
        )
        button_5.place(
            x=496.0,
            y=200.0,
            width=38.0,
            height=31.0
        )
        button_5.image = button_image_5