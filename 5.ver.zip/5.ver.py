import json
with open('recipes.json', 'r', encoding='utf-8') as file:
    recipes = json.load(file)
def print_recipes_menu():
    print("Доступные рецепты:")
    for recipe in recipes:
        print(f"- {recipe['name']} (Восстановление здоровья: {recipe['health_recovery']}, Стоимость: {recipe['cost']})")
def check_recipes(user_ingredients):
    matching_recipes = []
    for recipe in recipes:
        if all(any(ingredient_keyword.lower() in ingredient.lower() for ingredient in recipe['ingredients']) for ingredient_keyword in user_ingredients):
            matching_recipes.append(recipe)
    return matching_recipes
def search_recipes_by_name(keywords):
    matching_recipes = []
    for recipe in recipes:
        if any(keyword.lower() in recipe['name'].lower() for keyword in keywords):
            matching_recipes.append(recipe)
    return matching_recipes
while True:
    user_choice = input("Введите '1' для вывода списка рецептов, '2' для проверки ингредиентов или '3' для поиска по названию, '4' для выхода из программы: ")
    if user_choice == '1':
        print_recipes_menu()
    elif user_choice == '2':
        user_ingredients = input("Введите ингредиентов через пробел: ").split()
        matching_recipes = check_recipes(user_ingredients)
        if matching_recipes:
            print("Совпадающие рецепты:")
            for recipe in matching_recipes:
                print(f"{recipe['name']} (Восстановление здоровья: {recipe['health_recovery']}, Стоимость: {recipe['cost']}): {', '.join(recipe['ingredients'])}")
        else:
            print("Нет совпадающих рецептов.")
    elif user_choice == '3':
        keywords = input("Введите название рецепта: ").split()
        matching_recipes = search_recipes_by_name(keywords)
        if matching_recipes:
            print("Найденные рецепты:")
            for recipe in matching_recipes:
                print(f"{recipe['name']} (Восстановление здоровья: {recipe['health_recovery']}, Стоимость: {recipe['cost']}): {', '.join(recipe['ingredients'])}")
        else:
            print("Рецепты не найдены.")
    elif user_choice == '4':
        print("Выход из программы")
        break
    else:
        print("Неверный ввод. Введите 1, 2, 3, или 4 для выхода из программы.")